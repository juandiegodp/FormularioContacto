package com.juandiegodp.formulariocontacto;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        final EditText etFechaPicker = findViewById(R.id.etFechaPicker);
        etFechaPicker.setOnClickListener(this);

        final EditText etNombre = (EditText) findViewById(R.id.etNombre);
        final EditText etEmail = findViewById(R.id.etEmail);
        final EditText etTelefono = findViewById(R.id.etTelefono);
        final EditText etDescripcion = findViewById(R.id.etDescripcion);
        Button etbutton1 = (Button) findViewById(R.id.etbutton1);

        etbutton1.setOnClickListener (new View.OnClickListener(){

            public void onClick(View v) {

                Intent intent =  new Intent(MainActivity.this, ConfirmarDatos.class);

                intent.putExtra("Nombre", etNombre.getText().toString());
                intent.putExtra("Nacimiento", etFechaPicker.getText().toString());
                intent.putExtra("Telefono", etTelefono.getText().toString());
                intent.putExtra("Email", etEmail.getText().toString());
                intent.putExtra("Descripcion", etDescripcion.getText().toString());
                startActivityForResult(intent,1);

            }

        });







    }
    private EditText etNombre;
    private EditText etFechaPicker;
    private EditText etEmail;
    private EditText etTelefono;
    private EditText etDescripcion;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        if (requestCode == 1) {
            if(resultCode == RESULT_OK) {
                String nombre = data.getStringExtra("rNombre");
                String nacimiento= data.getStringExtra("rNacimiento");
                String telefono= data.getStringExtra("rTelefono");
                String email = data.getStringExtra("rEmail");
                String descripcion = data.getStringExtra("rDescripcion");

                etNombre = (EditText) findViewById(R.id.etNombre);
                etFechaPicker = (EditText) findViewById(R.id.etFechaPicker);
                etEmail = (EditText) findViewById(R.id.etEmail);
                etTelefono = (EditText) findViewById(R.id.etTelefono);
                etDescripcion = (EditText) findViewById(R.id.etDescripcion);

                etNombre.setText(nombre);
                etFechaPicker.setText(nacimiento);
                etEmail.setText(email);
                etTelefono.setText(telefono);
                etDescripcion.setText(descripcion);


            }
        }
    }




    public void onClick(View view) {
        //Determinamos qué elemento ha sido pulsado
        switch (view.getId()) {
            case R.id.etFechaPicker:
                //Mostrar el datePicker
                showDatePickerDialog((EditText) view);
                break;
        }
    }
    public void showDatePickerDialog(EditText v) {
        // Para crear una instancia de nuestro datePicker
        // pasándole el EditText debemos usar el método
        // estático que definimos como "newInstance"
        // en lugar de usar el constructor por defecto
        DialogFragment newFragment = DatePickerFragment.newInstance(v);
        // Mostrar el datePicker
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }


}