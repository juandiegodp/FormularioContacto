package com.juandiegodp.formulariocontacto;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ConfirmarDatos extends AppCompatActivity {

    private TextView tvnombre;
    private TextView tvnacimiento;
    private TextView tvtelefono;
    private TextView tvemail;
    private TextView tvdescripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);

        Bundle parametros = getIntent().getExtras();

        String nombre = parametros.getString("Nombre");
        String nacimiento = parametros.getString("Nacimiento");
        String telefono = parametros.getString("Telefono");
        String email = parametros.getString("Email");
        String descripcion = parametros.getString("Descripcion");

        tvnombre   = (TextView) findViewById(R.id.tvnombre);
        tvnacimiento = (TextView) findViewById(R.id.tvnacimiento);
        tvtelefono    = (TextView) findViewById(R.id.tvtelefono);
        tvemail    = (TextView) findViewById(R.id.tvemail);
        tvdescripcion    = (TextView) findViewById(R.id.tvdescripcion);

        tvnombre.setText(nombre);
        tvnacimiento.setText(nacimiento);
        tvtelefono.setText(telefono);
        tvemail.setText(email);
        tvdescripcion.setText(descripcion);

        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent  returnIntent =  new Intent(ConfirmarDatos.this, MainActivity.class);
                returnIntent.putExtra("rNombre",tvnombre.getText().toString());
                returnIntent.putExtra("rNacimiento",tvnacimiento.getText().toString());
                returnIntent.putExtra("rTelefono",tvtelefono.getText().toString());
                returnIntent.putExtra("rEmail",tvemail.getText().toString());
                returnIntent.putExtra("rDescripcion",tvdescripcion.getText().toString());
                setResult(Activity.RESULT_OK, returnIntent);
                finish();

            }
        });



    }

}
